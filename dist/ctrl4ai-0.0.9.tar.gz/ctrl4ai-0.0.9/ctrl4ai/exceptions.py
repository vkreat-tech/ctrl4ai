# -*- coding: utf-8 -*-
"""
Created on Sat Jun 27 23:43:31 2020

@author: ShajiJamesSelvakumar
"""

class ParameterError(Exception):
  """
  User Defined Exception
  Thrown because the argumrnt is incorrect
  """
  pass
