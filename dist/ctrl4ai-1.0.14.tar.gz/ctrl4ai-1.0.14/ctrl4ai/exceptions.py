# -*- coding: utf-8 -*-
"""
Created on Tue May 19 23:43:31 2020

@author: Shaji,Charu,Selva
"""


class ParameterError(Exception):
    """
    User Defined Exception
    Thrown because the argumrnt is incorrect
    """
    pass
